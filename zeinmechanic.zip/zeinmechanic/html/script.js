let currentMods = {};
let isMouseDown = false;
let selectedPearl = 0;
let selectedXenon = 0;

// LAMBRA-EXOTICPAINTS ID LİSTESİ (2024 FINAL)
const chameleonPaints = [
    {id: 161, name: "Anodized Red"}, {id: 162, name: "Anodized Wine"}, {id: 163, name: "Anodized Purple"},
    {id: 164, name: "Anodized Blue"}, {id: 165, name: "Anodized Green"}, {id: 166, name: "Anodized Lime"},
    {id: 167, name: "Anodized Copper"}, {id: 168, name: "Anodized Bronze"}, {id: 169, name: "Anodized Champagne"},
    {id: 170, name: "Anodized Gold"}, {id: 171, name: "Green/Blue Flip"}, {id: 172, name: "Green/Red Flip"},
    {id: 173, name: "Green/Brown Flip"}, {id: 174, name: "Green/Turq Flip"}, {id: 175, name: "Green/Purp Flip"},
    {id: 176, name: "Teal/Purp Flip"}, {id: 177, name: "Turq/Red Flip"}, {id: 178, name: "Turq/Purp Flip"},
    {id: 179, name: "Cyan/Purp Flip"}, {id: 180, name: "Blue/Pink Flip"}, {id: 181, name: "Blue/Green Flip"},
    {id: 182, name: "Purp/Red Flip"}, {id: 183, name: "Purp/Green Flip"}, {id: 184, name: "Magenta/Green Flip"},
    {id: 185, name: "Magenta/Yellow Flip"}, {id: 186, name: "Burg/Green Flip"}, {id: 187, name: "Magenta/Cyan Flip"},
    {id: 188, name: "Copper/Purp Flip"}, {id: 189, name: "Magenta/Orange Flip"}, {id: 190, name: "Red/Orange Flip"},
    {id: 191, name: "Orange/Purp Flip"}, {id: 192, name: "Orange/Blue Flip"}, {id: 193, name: "White/Purp Flip"},
    {id: 194, name: "Red Rainbow"}, {id: 195, name: "Blue Rainbow"}, {id: 196, name: "Dark Green Pearl"},
    {id: 197, name: "Dark Teal Pearl"}, {id: 198, name: "Dark Blue Pearl"}, {id: 199, name: "Dark Purple Pearl"},
    {id: 200, name: "Oil Slick Pearl"}, {id: 201, name: "Light Green Pearl"}, {id: 202, name: "Light Blue Pearl"},
    {id: 203, name: "Light Purp Pearl"}, {id: 204, name: "Light Pink Pearl"}, {id: 205, name: "Off White Pearl"},
    {id: 206, name: "Pink Pearl"}, {id: 207, name: "Yellow Pearl"}, {id: 208, name: "Green Pearl"},
    {id: 209, name: "Blue Pearl"}, {id: 210, name: "Cream Pearl"}, {id: 211, name: "White Prismatic"},
    {id: 212, name: "Graphite Prismatic"}, {id: 213, name: "Dark Blue Prismatic"}, {id: 214, name: "Dark Purp Prismatic"},
    {id: 215, name: "Hot Pink Prismatic"}, {id: 216, name: "Red Prismatic"}, {id: 217, name: "Green Prismatic"},
    {id: 218, name: "Black Prismatic"}, {id: 219, name: "Oil Slick Prismatic"}, {id: 220, name: "Rainbow Prismatic"},
    {id: 221, name: "Black Holographic"}, {id: 222, name: "White Holographic"}, {id: 223, name: "Monochrome"},
    {id: 224, name: "Nite/Day"}, {id: 225, name: "Verlierer"}, {id: 226, name: "Sprunk Extreme"},
    {id: 227, name: "Vice City"}, {id: 228, name: "Synthwave"}, {id: 229, name: "Four Seasons"},
    {id: 230, name: "M9 Throwback"}, {id: 231, name: "Bubblegum"}, {id: 232, name: "Full Rainbow"},
    {id: 233, name: "Sunsets"}, {id: 234, name: "The Seven"}, {id: 235, name: "Kamen Rider"},
    {id: 236, name: "Chroma Aberration"}, {id: 237, name: "Christmas"}, {id: 238, name: "Temperature"},
    {id: 239, name: "HSW"}, {id: 240, name: "Electro"}, {id: 241, name: "Monika"}, {id: 242, name: "Fubuki"}
];

const pearlColors = [
    {id: 0, hex: '#000000'}, {id: 1, hex: '#1c1d21'}, {id: 3, hex: '#2d3036'}, 
    {id: 111, hex: '#ffffff'}, {id: 27, hex: '#c00e1a'}, {id: 88, hex: '#ffcf20'}, 
    {id: 50, hex: '#0f4889'}, {id: 147, hex: '#101010'}
];

const xenonColors = [
    {id: 0, hex: '#ffffff', name: 'Stock'}, {id: 1, hex: '#0033ff', name: 'Blue'},
    {id: 2, hex: '#00ccff', name: 'Electric Blue'}, {id: 3, hex: '#66ffcc', name: 'Mint'},
    {id: 4, hex: '#ccff00', name: 'Lime'}, {id: 5, hex: '#ffff00', name: 'Yellow'},
    {id: 6, hex: '#ffcc00', name: 'Golden'}, {id: 7, hex: '#ff6600', name: 'Orange'},
    {id: 8, hex: '#ff0000', name: 'Red'}, {id: 9, hex: '#ff00cc', name: 'Pony Pink'},
    {id: 10, hex: '#cc00ff', name: 'Hot Pink'}, {id: 11, hex: '#6600ff', name: 'Purple'},
    {id: 12, hex: '#0000ff', name: 'Blacklight'}
];

$(document).ready(function() {
    initColorGrids();

    window.addEventListener('message', function(event) {
        if (event.data.action == "open") {
            $('#mainMenu').fadeIn(200);
            currentMods = event.data.mods || {};
            loadPerformance();
            loadCosmetics();
            loadChameleons();
            loadLiveries(event.data.liveryCount);
            openTab('performance');
        }
        if (event.data.action == "close") {
            $('#mainMenu').fadeOut(200);
        }
    });

    $('#closeMenu').click(closeMenu);
    document.onkeyup = function(data) { if (data.which == 27) closeMenu(); };

    // KAMERA
    $('#camControlArea').mousedown(function(e) {
        if (e.button == 2) { isMouseDown = true; $.post('https://zeinmechanic/camRotateStart', JSON.stringify({})); }
    });
    $(window).mouseup(function() {
        if (isMouseDown) { isMouseDown = false; $.post('https://zeinmechanic/camRotateStop', JSON.stringify({})); }
    });
    $('#camControlArea').mousemove(function(e) {
        if (isMouseDown) {
            let x = (e.clientX / window.innerWidth) * 2 - 1;
            $.post('https://zeinmechanic/camRotateMove', JSON.stringify({x: x}));
        }
    });
    window.addEventListener('wheel', function(event) {
        if ($('#mainMenu').is(":visible")) {
            let dir = event.deltaY > 0 ? "out" : "in";
            $.post('https://zeinmechanic/camZoom', JSON.stringify({ direction: dir }));
        }
    });

    // BUTONLAR
    $('#applyPaint').click(function() {
        let rgb = hexToRgb($('#primaryColor').val());
        $.post('https://zeinmechanic/applyPaint', JSON.stringify({ r: rgb.r, g: rgb.g, b: rgb.b, type: $('#paintType').val() }));
    });
    $('#applySecondary').click(function() {
        let rgb = hexToRgb($('#secondaryColor').val());
        $.post('https://zeinmechanic/applySecondary', JSON.stringify({ r: rgb.r, g: rgb.g, b: rgb.b, type: $('#paintType').val() }));
    });
    $('#applyPearl').click(function() { $.post('https://zeinmechanic/applyPearl', JSON.stringify({ pearl: selectedPearl })); });
    $('#applyPlate').click(function() { $.post('https://zeinmechanic/applyPlate', JSON.stringify({ text: $('#plateText').val(), index: $('#plateIndex').val() })); });
    $('#applyStance').click(function() {
        $.post('https://zeinmechanic/applyStance', JSON.stringify({ wF: $('#stanceWidthF').val(), wR: $('#stanceWidthR').val(), camber: $('#stanceCamber').val() }));
    });
    $('#applyNeon').click(function() {
        let rgb = hexToRgb($('#neonColorPicker').val());
        $.post('https://zeinmechanic/applyNeon', JSON.stringify({ r: rgb.r, g: rgb.g, b: rgb.b }));
    });
    $('#resetWheels').click(function() { $.post('https://zeinmechanic/resetWheels', JSON.stringify({})); });
});

function loadChameleons() {
    let container = $('#chameleonList'); container.html('');
    chameleonPaints.forEach(paint => { container.append(`<button class="mod-btn" onclick="applyChameleon(${paint.id})">${paint.name}</button>`); });
}
function initColorGrids() {
    let pHtml = ''; pearlColors.forEach(c => { pHtml += `<div class="color-swatch" style="background:${c.hex}" onclick="selectPearl(this, ${c.id})"></div>`; }); $('#pearlGrid').html(pHtml);
    let xHtml = ''; xenonColors.forEach(c => { xHtml += `<div class="color-swatch" style="background:${c.hex}" onclick="selectXenon(this, ${c.id})"></div>`; }); $('#xenonGrid').html(xHtml);
}
window.loadWheels = function(type) {
    let container = $('#wheels-list'); container.html('');
    for(let i=0; i<40; i++) container.append(`<button class="mod-btn" onclick="setWheel(${type}, ${i})">Model ${i+1}</button>`);
}

function loadLiveries(count) {
    let container = $('#livery-container'); container.html('');
    if (count && count > 0) {
        container.append(`<button class="mod-btn" onclick="setLivery(-1)">Livery Yok</button>`);
        for(let i=0; i<count; i++) container.append(`<button class="mod-btn" onclick="setLivery(${i})">Livery ${i+1}</button>`);
    } else {
        container.html('<div class="empty-msg">Bu araçta Livery bulunmuyor.</div>');
    }
}

// Helper Fonksiyonlar
function selectPearl(el, id) { $('.color-swatch').removeClass('active'); $(el).addClass('active'); selectedPearl = id; }
function selectXenon(el, id) { selectedXenon = id; $.post('https://zeinmechanic/applyXenon', JSON.stringify({ color: id })); }
window.applyChameleon = function(id) { $.post('https://zeinmechanic/applyChameleon', JSON.stringify({ id: id })); }
window.setLivery = function(idx) { $.post('https://zeinmechanic/applyLivery', JSON.stringify({ index: idx })); }
window.openTab = function(tabName) {
    $('.tab-content').hide(); $('#' + tabName).fadeIn(200);
    $('.nav-item').removeClass('active'); $(event.currentTarget).addClass('active');
    $.post('https://zeinmechanic/changeCam', JSON.stringify({ tab: tabName }));
}
window.setMod = function(t, i) { $.post('https://zeinmechanic/applyMod', JSON.stringify({ type: t, index: i })); }
window.setWheel = function(t, i) { $.post('https://zeinmechanic/applyWheel', JSON.stringify({ type: t, index: i })); }
window.toggleXenon = function() { $.post('https://zeinmechanic/toggleXenon', JSON.stringify({})); }
function hexToRgb(hex) { var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex); return result ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) } : null; }
function closeMenu() { $.post('https://zeinmechanic/closeMenu', JSON.stringify({})); }
function loadPerformance() { let container = $('#perf-container'); container.html(''); const items = [ { label: "Motor", type: 11 }, { label: "Frenler", type: 12 }, { label: "Şanzıman", type: 13 }, { label: "Süspansiyon", type: 15 }, { label: "Turbo", type: 18 } ]; items.forEach(item => { let max = (currentMods[item.type] !== undefined) ? currentMods[item.type] : -1; let html = `<label>${item.label}</label><div class="grid-list">`; if (item.type == 18) { html += `<button class="mod-btn" onclick="setMod(18, -1)">Yok</button><button class="mod-btn" onclick="setMod(18, 1)">Var</button>`; } else { html += `<button class="mod-btn" onclick="setMod(${item.type}, -1)">Stok</button>`; if (max > 0) for(let i=0; i<max; i++) html += `<button class="mod-btn" onclick="setMod(${item.type}, ${i})">Seviye ${i+1}</button>`; } if (max <= 0 && item.type != 18) html = `<label>${item.label}</label><div class="empty-msg">Parça yok.</div>`; else html += `</div>`; container.append(html); }); }
function loadCosmetics() { let container = $('#cosmetics-container'); container.html(''); const cosmetics = [ { id: 0, name: "Spoiler" }, { id: 1, name: "Ön Tampon" }, { id: 2, name: "Arka Tampon" }, { id: 3, name: "Marşpiyel" }, { id: 4, name: "Egzoz" }, { id: 7, name: "Kaput" }, { id: 22, name: "Xenon" } ]; let has = false; cosmetics.forEach(item => { let count = (currentMods[item.id] !== undefined) ? currentMods[item.id] : 0; if (count > 0) { has = true; let html = `<label>${item.name} (${count})</label><div class="grid-list">`; html += `<button class="mod-btn" onclick="setMod(${item.id}, -1)">Orjinal</button>`; for(let i=0; i<count; i++) html += `<button class="mod-btn" onclick="setMod(${item.id}, ${i})">Parça ${i+1}</button>`; html += `</div>`; container.append(html); } }); if (!has) container.append('<div class="empty-msg">Görünüm parçası bulunamadı.</div>'); }