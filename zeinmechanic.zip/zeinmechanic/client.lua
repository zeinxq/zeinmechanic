local QBCore = exports['qb-core']:GetCoreObject()
local cam = nil
local inMenu = false
local isRotating = false
local camAngle = 0.0
local camDist = 5.0
local camHeight = 1.5
local targetVehicle = nil

-- Build Kontrolü
if GetGameBuildNumber() < 2699 then 
    print("^1[ZeinMechanic] HATA: Gamebuild 2699 veya üzeri gereklidir. Şu anki Build: "..GetGameBuildNumber().."^0") 
end

RegisterCommand('z', function()
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) then
        targetVehicle = GetVehiclePedIsIn(ped, false)
        OpenMenu(targetVehicle)
    else
        QBCore.Functions.Notify("Araca binmelisin!", "error")
    end
end)

function OpenMenu(vehicle)
    inMenu = true
    SetNuiFocus(true, true)
    
    SetVehicleModKit(vehicle, 0)
    local modCounts = {}
    for i = 0, 49 do
        local c = GetNumVehicleMods(vehicle, i)
        if not c then c = 0 end
        modCounts[i] = c
    end
    
    local liveryCount = GetVehicleLiveryCount(vehicle)
    local liveryModCount = GetNumVehicleMods(vehicle, 48)
    local finalLiveryCount = (liveryModCount > liveryCount) and liveryModCount or liveryCount

    SendNUIMessage({ 
        action = "open", 
        mods = modCounts,
        liveryCount = finalLiveryCount 
    })

    CreateCamFocus(vehicle)
    FreezeEntityPosition(vehicle, true)
    SetVehicleLights(vehicle, 2)
    
    CreateThread(function()
        while inMenu do
            if cam then
                local coords = GetEntityCoords(targetVehicle)
                local x = coords.x + (camDist * math.cos(camAngle))
                local y = coords.y + (camDist * math.sin(camAngle))
                SetCamCoord(cam, x, y, coords.z + camHeight)
                PointCamAtEntity(cam, targetVehicle, 0.0, 0.0, 0.0, true)
            end
            Wait(0)
        end
    end)
end

function CreateCamFocus(vehicle)
    if not DoesCamExist(cam) then cam = CreateCam("DEFAULT_SCRIPTED_CAMERA", true) end
    local offset = GetOffsetFromEntityInWorldCoords(vehicle, -4.0, 4.0, 1.5)
    SetCamCoord(cam, offset.x, offset.y, offset.z)
    PointCamAtEntity(cam, vehicle, 0.0, 0.0, 0.0, true)
    SetCamActive(cam, true)
    RenderScriptCams(true, true, 800, true, true)
    camAngle = 1.5
end

RegisterNUICallback('camZoom', function(data, cb)
    if data.direction == "in" then camDist = math.max(2.0, camDist - 0.5)
    elseif data.direction == "out" then camDist = math.min(8.0, camDist + 0.5) end
    cb('ok')
end)

RegisterNUICallback('camRotateStart', function(_, cb) isRotating = true cb('ok') end)
RegisterNUICallback('camRotateStop', function(_, cb) isRotating = false cb('ok') end)
RegisterNUICallback('camRotateMove', function(data, cb)
    if isRotating then camAngle = camAngle - (tonumber(data.x) * 0.1) end
    cb('ok')
end)

RegisterNUICallback('changeCam', function(data, cb)
    if data.tab == "performance" then
        SetVehicleDoorOpen(targetVehicle, 4, false, false)
        camDist = 4.0; camHeight = 2.0;
    elseif data.tab == "wheels" then
        camDist = 3.5; camHeight = 0.8; 
        SetVehicleDoorShut(targetVehicle, 4, false)
    else
        SetVehicleDoorShut(targetVehicle, 4, false)
        camDist = 6.0; camHeight = 1.5;
    end
    cb('ok')
end)

-- *** CHAMELEON FIX (KRİTİK BÖLÜM) ***
RegisterNUICallback('applyChameleon', function(data, cb)
    local id = tonumber(data.id)
    
    -- 1. Özel RGB (Custom) Renkleri Kesinlikle SİL.
    ClearVehicleCustomPrimaryColour(targetVehicle)
    ClearVehicleCustomSecondaryColour(targetVehicle)
    
    -- 2. Normal boya tipini ayarla (Metalik veya Mat olursa Chameleon bozulabilir)
    SetVehicleModColor_1(targetVehicle, 0, 0, 0) -- 0: Normal
    SetVehicleModColor_2(targetVehicle, 0, 0, 0)
    
    -- 3. Sedef rengini sıfırla
    local _, wheel = GetVehicleExtraColours(targetVehicle)
    SetVehicleExtraColours(targetVehicle, 0, wheel) 

    -- 4. Chameleon Rengini Ata
    SetVehicleColours(targetVehicle, id, id)
    
    cb('ok')
end)

RegisterNUICallback('applyPaint', function(data, cb)
    SetVehicleCustomPrimaryColour(targetVehicle, tonumber(data.r), tonumber(data.g), tonumber(data.b))
    SetVehicleModColor_1(targetVehicle, tonumber(data.type), 0, 0)
    cb('ok')
end)
RegisterNUICallback('applySecondary', function(data, cb)
    SetVehicleCustomSecondaryColour(targetVehicle, tonumber(data.r), tonumber(data.g), tonumber(data.b))
    SetVehicleModColor_2(targetVehicle, tonumber(data.type), 0, 0)
    cb('ok')
end)
RegisterNUICallback('applyPearl', function(data, cb)
    local _, wColor = GetVehicleExtraColours(targetVehicle)
    SetVehicleExtraColours(targetVehicle, tonumber(data.pearl), wColor)
    cb('ok')
end)
RegisterNUICallback('applyLivery', function(data, cb)
    local index = tonumber(data.index)
    SetVehicleLivery(targetVehicle, index)
    SetVehicleMod(targetVehicle, 48, index, false)
    cb('ok')
end)
RegisterNUICallback('applyPlate', function(data, cb)
    local text = data.text or "ZEIN"
    local index = tonumber(data.index) or 0
    if text:len() > 8 then text = text:sub(1, 8) end
    SetVehicleNumberPlateText(targetVehicle, text)
    SetVehicleNumberPlateTextIndex(targetVehicle, index)
    TriggerServerEvent("zeinmechanic:server:giveKeys", text)
    cb('ok')
end)
RegisterNUICallback('applyStance', function(data, cb)
    local wF = tonumber(data.wF); local wR = tonumber(data.wR)
    if wF > 0.3 then wF = 0.3 end; if wR > 0.3 then wR = 0.3 end
    SetVehicleHandlingFloat(targetVehicle, "CHandlingData", "fTrackWidth", 1.0 + wF)
    local camber = tonumber(data.camber)
    SetVehicleWheelYRotation(targetVehicle, 0, -camber); SetVehicleWheelYRotation(targetVehicle, 1, camber)
    SetVehicleWheelYRotation(targetVehicle, 2, -camber); SetVehicleWheelYRotation(targetVehicle, 3, camber)
    SetVehicleModKit(targetVehicle, 0)
    cb('ok')
end)
RegisterNUICallback('applyWheel', function(data, cb) SetVehicleWheelType(targetVehicle, tonumber(data.type)); SetVehicleMod(targetVehicle, 23, tonumber(data.index), false); if IsThisModelABike(GetEntityModel(targetVehicle)) then SetVehicleMod(targetVehicle, 24, tonumber(data.index), false) end; cb('ok') end)
RegisterNUICallback('resetWheels', function(data, cb) SetVehicleMod(targetVehicle, 23, -1, false); if IsThisModelABike(GetEntityModel(targetVehicle)) then SetVehicleMod(targetVehicle, 24, -1, false) end; cb('ok') end)
RegisterNUICallback('toggleXenon', function(data, cb) local current = IsToggleModOn(targetVehicle, 22); ToggleVehicleMod(targetVehicle, 22, not current); cb('ok') end)
RegisterNUICallback('applyXenon', function(data, cb) ToggleVehicleMod(targetVehicle, 22, true); SetVehicleXenonLightsColor(targetVehicle, tonumber(data.color)); cb('ok') end)
RegisterNUICallback('applyNeon', function(data, cb) for i=0, 3 do SetVehicleNeonLightEnabled(targetVehicle, i, true) end; SetVehicleNeonLightsColour(targetVehicle, tonumber(data.r), tonumber(data.g), tonumber(data.b)); cb('ok') end)
RegisterNUICallback('applyMod', function(data, cb) SetVehicleMod(targetVehicle, tonumber(data.type), tonumber(data.index), false); cb('ok') end)
RegisterNUICallback('closeMenu', function(data, cb)
    inMenu = false; isRotating = false; SetNuiFocus(false, false); SendNUIMessage({ action = "close" })
    RenderScriptCams(false, true, 800, true, true); DestroyCam(cam, false); cam = nil
    FreezeEntityPosition(targetVehicle, false); cb('ok')
end)