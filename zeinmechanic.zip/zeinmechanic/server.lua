local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('zeinmechanic:server:giveKeys', function(plate)
    local src = source
    TriggerClientEvent('vehiclekeys:client:SetOwner', src, plate)
end)